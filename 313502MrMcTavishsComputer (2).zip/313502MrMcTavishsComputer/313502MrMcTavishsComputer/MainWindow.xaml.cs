﻿/* Elliott McArthur
 * March 1, 2019
 * Computer parts assignment
 */
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace _313502MrMcTavishsComputer
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
       
       
       
        public MainWindow()
        {
            
            {
             
            }
        }
       
         
        private void btnRAM_Click(object sender, RoutedEventArgs e)
        {
            RAMwindow rw = new RAMwindow();
                rw.ShowDialog();
        }

        private void btnMotherboard_Click(object sender, RoutedEventArgs e)
        {
            Motherboard mw = new Motherboard();
                mw.ShowDialog();
        }

        private void btnCPU_Click(object sender, RoutedEventArgs e)
        {
            CPUwindow cw = new CPUwindow();
                cw.ShowDialog();
        }

        private void btnStorage_Click(object sender, RoutedEventArgs e)
        {
            Storage sw = new Storage();
                sw.ShowDialog();
        }

        private void btnOptical_Click(object sender, RoutedEventArgs e)
        {
            Optical ow = new Optical();
                ow.ShowDialog();
        }

        private void btnGraphics_Click(object sender, RoutedEventArgs e)
        {
            Graphics gw = new Graphics();
                gw.ShowDialog();
        }

        private void btnPowerSupply_Click(object sender, RoutedEventArgs e)
        {
            PowerSupply psw = new PowerSupply();
                psw.ShowDialog();
        }

        private void btnCase_Click(object sender, RoutedEventArgs e)
        {
            Case caw = new Case();
                caw.ShowDialog();
        }
    }
}
